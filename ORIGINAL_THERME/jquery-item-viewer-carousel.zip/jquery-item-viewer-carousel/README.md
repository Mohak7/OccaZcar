# jquery-item-viewer
The item viewer is an example of an image gallery. When you click on a thumbnail, the main photograph is replaced with a new item.
